<!DOCTYPE HTML>
<html>
<head>
<title>Usuario</title>
<script type="text/javascript" src="/aulafiecyft/web/js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="/aulafiecyft/web/js/js.js"></script>
<link rel="stylesheet" type="text/css" href="../web/css/default.css" />
</head>
<body>
<div class="content">
<ul id="menu">
    <li>Proyectos</li>
    <li>Clientes</li>
    <li>Tareas</li>
</ul>
<h1 id="tituloUsuario" class="titulo">Usuario</h1>
<form>
<fieldset>
<legend>INICIAR SESI&Oacute;N</legend>
<br />
Usuario: <input type="text" name="usuario"/><br />
Pass: <input type="password" name="pass"/><br />
<input type="submit" value="Inciar Sesi&oacute;n"/>
</fieldset>
</form> 
</div>


</body>
</html>